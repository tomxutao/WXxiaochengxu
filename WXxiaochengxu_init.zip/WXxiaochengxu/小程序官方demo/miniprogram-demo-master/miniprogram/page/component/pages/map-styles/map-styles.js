Page({
  onShareAppMessage() {
    return {
      title: 'map底图样式',
      path: 'page/component/pages/map-styles/map-styles'
    }
  },
})
